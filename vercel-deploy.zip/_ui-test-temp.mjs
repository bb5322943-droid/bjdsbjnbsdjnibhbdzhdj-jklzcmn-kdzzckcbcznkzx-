import { chromium } from "playwright";

const OUT = "C:\\Users\\user\\AppData\\Local\\Temp\\claude\\c--Users-user-Desktop-fusion-starter-fab\\ed32f703-972f-41d7-9b6f-eac0ecb74549\\scratchpad";
const BASE = "http://localhost:8081";
const shot = (page, name) => page.screenshot({ path: `${OUT}\\shot-${name}.png`, fullPage: false });

const consoleErrors = [];

async function main() {
  const browser = await chromium.launch({
    executablePath:
      "C:\\Users\\user\\AppData\\Local\\ms-playwright\\chromium-1228\\chrome-win64\\chrome.exe",
    headless: true,
    args: ["--no-sandbox"],
  });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  page.on("console", (msg) => {
    if (msg.type() === "error") consoleErrors.push(msg.text());
  });
  page.on("pageerror", (err) => consoleErrors.push("PAGEERROR: " + err.message));

  const results = [];
  const check = (name, ok, d = "") => {
    results.push({ name, ok, d });
    console.log(`${ok ? "PASS" : "FAIL"}  ${name}${d ? "  — " + d : ""}`);
  };

  // 1. LOGIN
  await page.goto(BASE + "/login", { waitUntil: "networkidle" });
  await page.fill("#email", "sardor.mahmudov@company.uz");
  await page.fill("#password", "Orbis2026!");
  await shot(page, "01-login");
  await page.click('button[type="submit"]');
  await page.waitForURL(BASE + "/", { timeout: 15000 }).catch(() => {});
  await page.waitForSelector("text=Daromad va xarajatlar", { timeout: 15000 });
  check("Login muvaffaqiyatli, dashboard yuklandi", true);
  await page.waitForTimeout(1500);
  await shot(page, "02-dashboard");

  // 2. STATISTIKA TOOLTIP — 5-kun rect ustiga hover
  const rects = await page.$$("svg rect[fill='transparent']");
  check("Grafik sezgir zonalari topildi", rects.length > 0, `${rects.length} ta zona`);
  let tooltipText = "";
  if (rects.length > 4) {
    await rects[4].hover({ force: true });
    await page.waitForTimeout(600);
    const tip = await page.$("text=/\\d+-(yanvar|fevral|mart|aprel|may|iyun|iyul|avgust|sentabr|oktabr|noyabr|dekabr)/");
    if (tip) tooltipText = (await tip.innerText()).trim();
    await shot(page, "03-tooltip-5kun");
  }
  check("Tooltip '5-iyul' formatida ko'rsatadi", /^\d+-[a-z]+$/i.test(tooltipText), `tooltip: "${tooltipText}"`);

  // 3. ASOSIY SAHIFALAR
  const pages = [
    { path: "/warehouse", marker: "text=/Ombor|Mahsulot/", name: "04-warehouse" },
    { path: "/crm", marker: "text=/CRM|Bitim|Savdo/", name: "05-crm" },
    { path: "/hr", marker: "text=/Xodim|Kadr/", name: "06-hr" },
    { path: "/finance", marker: "text=/Moliya|Tranzaksiya|Daromad/", name: "07-finance" },
    { path: "/orders", marker: "text=/Buyurtma/", name: "08-orders" },
    { path: "/reports", marker: "text=/Hisobot/", name: "09-reports" },
  ];
  for (const p of pages) {
    try {
      await page.goto(BASE + p.path, { waitUntil: "networkidle", timeout: 15000 });
      await page.waitForSelector(p.marker, { timeout: 10000 });
      await page.waitForTimeout(500);
      await shot(page, p.name);
      check(`Sahifa yuklandi: ${p.path}`, true);
    } catch (e) {
      await shot(page, p.name + "-FAIL");
      check(`Sahifa yuklandi: ${p.path}`, false, e.message.split("\n")[0]);
    }
  }

  // 4. CONSOLE XATOLAR
  const realErrors = consoleErrors.filter(
    (e) => !/DevTools|Download the React|favicon|sourcemap/i.test(e),
  );
  check("Console jiddiy xatosiz", realErrors.length === 0, `${realErrors.length} ta xato`);
  if (realErrors.length) realErrors.slice(0, 8).forEach((e) => console.log("   CONSOLE: " + e.slice(0, 160)));

  const pass = results.filter((r) => r.ok).length;
  console.log(`\n===== UI NATIJA: ${pass}/${results.length} PASS =====`);
  await browser.close();
}
main().catch((e) => { console.error("SKRIPT XATOSI:", e); process.exit(1); });
